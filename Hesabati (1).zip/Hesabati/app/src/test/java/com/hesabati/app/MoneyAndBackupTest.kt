package com.hesabati.app

import com.hesabati.app.data.BackupException
import com.hesabati.app.data.BackupJson
import com.hesabati.app.data.CategoryEntity
import com.hesabati.app.data.DebtEntity
import com.hesabati.app.data.DebtPaymentEntity
import com.hesabati.app.data.Kind
import com.hesabati.app.data.TransactionEntity
import com.hesabati.app.domain.Money
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class MoneyTest {
    private fun ok(s: String, zero: Boolean = false) = (Money.parse(s, zero) as Money.ParseResult.Ok).value
    private fun bad(s: String, zero: Boolean = false) = assertTrue("يجب رفض: «$s»", Money.parse(s, zero) is Money.ParseResult.Error)

    @Test fun rejectsEmptyZeroNegativeAndFractions() {
        bad(""); bad("   "); bad("0"); bad("000"); bad("-5"); bad("12.5"); bad("12٫5"); bad("abc"); bad("1e5")
    }

    @Test fun acceptsGroupedAndArabicDigits() {
        assertEquals(1_250_000L, ok("1,250,000"))
        assertEquals(500L, ok("٥٠٠"))
        assertEquals(0L, ok("0", zero = true))
        assertEquals(999_999_999_999L, ok("999999999999"))
    }

    @Test fun rejectsTooLarge() { bad("1000000000000"); bad("99999999999999999999") }

    @Test fun formatsWithThousandsSeparator() {
        assertEquals("1,250,000 د.ع", Money.format(1_250_000))
        assertEquals("-60,000 د.ع", Money.format(-60_000))
    }
}

class BackupJsonTest {
    private val data = BackupJson.Data(
        500_000,
        listOf(CategoryEntity(1, "طعام")),
        listOf(TransactionEntity(1, Kind.EXPENSE, 30_000, "طعام", "غداء \"مع\" الأهل", 1_000)),
        listOf(DebtEntity(1, Kind.LENT, "أحمد", 100_000, "ملاحظة", 2_000)),
        listOf(DebtPaymentEntity(1, 1, 40_000, 3_000))
    )

    @Test fun roundTrip() {
        assertEquals(data, BackupJson.parse(BackupJson.toJson(data, 5_000)))
    }

    private fun rejected(text: String) {
        try { BackupJson.parse(text); fail("كان يجب رفض الملف") } catch (e: BackupException) { /* المتوقع */ }
    }

    @Test fun rejectsCorruptAndForeignFiles() {
        rejected("not json"); rejected("{}"); rejected("""{"format":"other","version":1}""")
        val json = BackupJson.toJson(data, 1)
        rejected(json.substring(0, json.length / 2))
    }

    @Test fun rejectsNewerVersion() {
        rejected(BackupJson.toJson(data, 1).replace("\"version\": 1", "\"version\": 2"))
    }

    @Test fun rejectsInconsistentPayments() {
        val over = data.copy(payments = listOf(DebtPaymentEntity(1, 1, 100_001, 3_000)))
        rejected(BackupJson.toJson(over, 1))
        val orphan = data.copy(payments = listOf(DebtPaymentEntity(1, 99, 10, 3_000)))
        rejected(BackupJson.toJson(orphan, 1))
    }
}
