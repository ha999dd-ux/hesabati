package com.hesabati.app

import com.hesabati.app.data.DebtEntity
import com.hesabati.app.data.DebtPaymentEntity
import com.hesabati.app.data.Kind
import com.hesabati.app.data.TransactionEntity
import com.hesabati.app.domain.FinanceCalculator
import com.hesabati.app.domain.Ledger
import com.hesabati.app.domain.TxFilter
import com.hesabati.app.domain.filterTransactions
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/** يبني دفتراً مالياً خطوة بخطوة بزمن متصاعد (كل حركة بعد السابقة). */
private class L(var opening: Long = 500_000) {
    var clock = 1_000L
    var nextId = 1L
    val txs = mutableListOf<TransactionEntity>()
    val debts = mutableListOf<DebtEntity>()
    val pays = mutableListOf<DebtPaymentEntity>()
    fun tick() { clock += 1_000 }

    fun income(a: Long, cat: String = "راتب") { tick(); txs += TransactionEntity(nextId++, Kind.INCOME, a, cat, "", clock) }
    fun expense(a: Long, cat: String = "طعام") { tick(); txs += TransactionEntity(nextId++, Kind.EXPENSE, a, cat, "", clock) }
    fun lend(person: String, a: Long): Long { tick(); val id = nextId++; debts += DebtEntity(id, Kind.LENT, person, a, "", clock); return id }
    fun borrow(person: String, a: Long): Long { tick(); val id = nextId++; debts += DebtEntity(id, Kind.BORROWED, person, a, "", clock); return id }
    fun pay(debtId: Long, a: Long) { tick(); pays += DebtPaymentEntity(nextId++, debtId, a, clock) }
    val ledger get() = Ledger(opening, txs.toList(), debts.toList(), pays.toList())
    val s get() = FinanceCalculator.summary(ledger)
}

class FinanceCalculatorTest {

    @Test fun scenario1_ordinary() {
        val l = L(500_000); l.income(100_000); l.expense(30_000)
        assertEquals(570_000L, l.s.cash)
        assertEquals(0L, l.s.owedToMe)
        assertEquals(0L, l.s.owedByMe)
        assertEquals(570_000L, l.s.net)
    }

    @Test fun scenario2_lendAndCollect() {
        val l = L(500_000); l.income(100_000); l.expense(30_000)
        val d = l.lend("أحمد", 100_000); l.pay(d, 40_000)
        assertEquals(510_000L, l.s.cash)
        assertEquals(60_000L, l.s.owedToMe)
        assertEquals(570_000L, l.s.net)
    }

    @Test fun scenario3_borrowAndRepay() {
        val l = L(500_000); l.income(100_000); l.expense(30_000)
        val a = l.lend("أحمد", 100_000); l.pay(a, 40_000)
        val b = l.borrow("علي", 50_000); l.pay(b, 20_000)
        assertEquals(540_000L, l.s.cash)
        assertEquals(60_000L, l.s.owedToMe)
        assertEquals(30_000L, l.s.owedByMe)
        assertEquals(570_000L, l.s.net)
    }

    @Test fun scenario4_expenseBeyondCash() {
        val l = L(500_000); l.income(100_000); l.expense(30_000)
        val a = l.lend("أحمد", 100_000); l.pay(a, 40_000)
        val b = l.borrow("علي", 50_000); l.pay(b, 20_000)
        l.expense(600_000)
        assertEquals(-60_000L, l.s.cash)
        assertEquals(60_000L, l.s.owedToMe)
        assertEquals(30_000L, l.s.owedByMe)
        assertEquals(-30_000L, l.s.net)
    }

    @Test fun multipleDebtsSamePersonAreIndependent() {
        val l = L(0)
        val d1 = l.lend("سعد", 100_000); val d2 = l.lend("سعد", 50_000)
        l.pay(d1, 100_000)
        val views = FinanceCalculator.debtViews(l.ledger).associateBy { it.debt.id }
        assertTrue(views.getValue(d1).isPaid)
        assertFalse(views.getValue(d2).isPaid)
        assertEquals(50_000L, views.getValue(d2).remaining)
        assertEquals(50_000L, l.s.owedToMe) // المسدد لا يدخل الإجمالي
    }

    @Test fun fullPaymentMakesDebtPaid() {
        val l = L(0); val d = l.borrow("منى", 70_000)
        l.pay(d, 30_000); l.pay(d, 40_000)
        val v = FinanceCalculator.debtViews(l.ledger).single()
        assertEquals(0L, v.remaining); assertTrue(v.isPaid)
        assertEquals(0L, l.s.owedByMe); assertEquals(0L, l.s.cash)
    }

    @Test fun editingOldTransactionUpdatesEverything() {
        val l = L(500_000); l.income(100_000); l.expense(30_000)
        val old = l.txs[1] // المصروف
        val edited = l.ledger.copy(transactions = listOf(l.txs[0], old.copy(amount = 80_000)))
        assertEquals(520_000L, FinanceCalculator.summary(edited).cash)
        val deleted = l.ledger.copy(transactions = listOf(l.txs[0]))
        assertEquals(600_000L, FinanceCalculator.summary(deleted).cash)
    }

    @Test fun debtsNeverAppearAsIncomeOrExpense() {
        val l = L(100_000); val a = l.borrow("علي", 50_000); l.pay(a, 20_000)
        val r = FinanceCalculator.report(l.ledger, 0, Long.MAX_VALUE / 4)
        assertEquals(0L, r.income); assertEquals(0L, r.expense); assertEquals(0L, r.netOrdinary)
        assertEquals(50_000L, r.borrowed); assertEquals(20_000L, r.repaid)
        assertEquals(30_000L, r.netDebtCash)
        assertEquals(130_000L, r.closingCash)
    }

    @Test fun reportReconcilesOpeningAndClosing() {
        val l = L(500_000)
        l.income(100_000); l.expense(30_000)              // قبل الفترة
        val start = l.clock + 500
        l.income(200_000, "مكافأة"); l.expense(50_000, "نقل")
        val d = l.lend("أحمد", 100_000); l.pay(d, 40_000)
        val b = l.borrow("علي", 80_000); l.pay(b, 10_000)
        val end = l.clock + 500
        l.expense(999)                                      // بعد الفترة
        val r = FinanceCalculator.report(l.ledger, start, end)
        assertEquals(570_000L, r.openingCash)
        assertEquals(200_000L, r.income); assertEquals(50_000L, r.expense)
        assertEquals(150_000L, r.netOrdinary)
        assertEquals(-100_000L + 40_000L + 80_000L - 10_000L, r.netDebtCash)
        assertEquals(r.openingCash + r.netOrdinary + r.netDebtCash, r.closingCash)
        assertEquals(60_000L, r.owedToMeAtEnd); assertEquals(70_000L, r.owedByMeAtEnd)
        assertEquals(listOf("مكافأة" to 200_000L), r.incomeByCategory)
    }

    @Test fun filterAppliesAllConditionsTogether() {
        val l = L(0)
        l.income(100, "راتب"); l.expense(500, "طعام"); l.expense(900, "طعام"); l.expense(700, "نقل")
        val f = TxFilter(type = Kind.EXPENSE, categoryName = "طعام", minAmount = 600, maxAmount = 1000)
        val r = filterTransactions(l.txs, f)
        assertEquals(1, r.size); assertEquals(900L, r[0].amount)
        assertEquals(4, filterTransactions(l.txs, TxFilter()).size)
    }

    @Test fun overflowIsDetectedNotWrapped() {
        val l = L(Long.MAX_VALUE); l.income(1)
        try { l.s; fail("كان يجب رفض التجاوز") } catch (e: ArithmeticException) { /* المتوقع */ }
    }
}
