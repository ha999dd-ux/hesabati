package com.hesabati.app.data

import androidx.room.withTransaction
import com.hesabati.app.domain.FinanceCalculator
import com.hesabati.app.domain.Ledger
import com.hesabati.app.domain.Money
import com.hesabati.app.domain.Names
import kotlinx.coroutines.CancellationException

sealed interface Outcome {
    data class Ok(val message: String) : Outcome
    data class Fail(val message: String) : Outcome
}

/** كل عمليات الكتابة تتم داخل معاملة واحدة؛ فإما أن تنجح كاملة أو لا يُحفظ شيء. */
class Repository(private val db: AppDatabase) {
    private val settings = db.settingsDao()
    private val categories = db.categoryDao()
    private val txs = db.transactionDao()
    private val debts = db.debtDao()
    private val pays = db.paymentDao()

    val settingsFlow = settings.observe()
    val categoriesFlow = categories.observeAll()
    val transactionsFlow = txs.observeAll()
    val debtsFlow = debts.observeAll()
    val paymentsFlow = pays.observeAll()

    private suspend fun ledgerNow() = Ledger(
        settings.get()?.openingBalance ?: 0L, txs.getAll(), debts.getAll(), pays.getAll()
    )

    /** يحسب الأرصدة بعد الكتابة للتأكد من عدم تجاوز الحدود العددية؛ وإلا تُلغى المعاملة. */
    private suspend fun verifyLedger() {
        FinanceCalculator.summary(ledgerNow())
    }

    /** block يعيد null عند النجاح أو رسالة خطأ عربية عند فشل التحقق. */
    private suspend fun run(okMessage: String, block: suspend () -> String?): Outcome = try {
        var failure: String? = null
        db.withTransaction {
            failure = block()
            if (failure == null) verifyLedger()
        }
        failure?.let { Outcome.Fail(it) } ?: Outcome.Ok(okMessage)
    } catch (e: CancellationException) {
        throw e
    } catch (e: ArithmeticException) {
        Outcome.Fail("المبلغ كبير جداً، لم يتم حفظ أي تغيير")
    } catch (e: Exception) {
        Outcome.Fail("تعذر إتمام العملية ولم يتم حفظ أي تغيير. حاول مرة أخرى")
    }

    // ---------- الإعداد الأولي والرصيد الافتتاحي ----------

    suspend fun completeSetup(opening: Long, firstCategory: String): Outcome = run("تم الإعداد بنجاح") {
        val name = Names.normalize(firstCategory)
        if (name.isEmpty()) return@run "اكتب اسم التصنيف الأول"
        if (name.length > Names.MAX_LEN) return@run "اسم التصنيف طويل جداً"
        settings.upsert(SettingsEntity(1, opening))
        categories.insert(CategoryEntity(name = name))
        null
    }

    suspend fun setOpeningBalance(value: Long): Outcome = run("تم تعديل الرصيد الافتتاحي") {
        settings.upsert(SettingsEntity(1, value))
        null
    }

    // ---------- التصنيفات ----------

    suspend fun addCategory(rawName: String): Outcome = run("تمت إضافة التصنيف") {
        val name = Names.normalize(rawName)
        if (name.isEmpty()) return@run "اكتب اسم التصنيف"
        if (name.length > Names.MAX_LEN) return@run "اسم التصنيف طويل جداً"
        if (categories.countByName(name, -1) > 0) return@run "يوجد تصنيف بهذا الاسم مسبقاً"
        categories.insert(CategoryEntity(name = name))
        null
    }

    suspend fun renameCategory(id: Long, rawName: String): Outcome = run("تم تعديل التصنيف") {
        val name = Names.normalize(rawName)
        if (name.isEmpty()) return@run "اكتب اسم التصنيف"
        if (name.length > Names.MAX_LEN) return@run "اسم التصنيف طويل جداً"
        if (categories.countByName(name, id) > 0) return@run "يوجد تصنيف بهذا الاسم مسبقاً"
        categories.rename(id, name)
        null
    }

    suspend fun deleteCategory(id: Long): Outcome = run("تم حذف التصنيف") {
        categories.deleteById(id)
        null
    }

    // ---------- الواردات والمصروفات ----------

    suspend fun saveTransaction(
        id: Long, type: String, amount: Long, categoryName: String, note: String, dateTime: Long
    ): Outcome = run("تم حفظ العملية بنجاح") {
        if (type != Kind.INCOME && type != Kind.EXPENSE) return@run "نوع العملية غير صحيح"
        if (amount < 1 || amount > MAX_AMOUNT) return@run "المبلغ غير صالح"
        val cat = Names.normalize(categoryName)
        if (cat.isEmpty()) return@run "اختر التصنيف أولاً"
        val cleanNote = note.trim()
        if (id == 0L) {
            if (categories.countByName(cat, -1) == 0) return@run "التصنيف المختار لم يعد موجوداً"
            txs.insert(TransactionEntity(0, type, amount, cat, cleanNote, dateTime))
        } else {
            val old = txs.getById(id) ?: return@run "العملية لم تعد موجودة"
            if (cat != old.categoryName && categories.countByName(cat, -1) == 0) return@run "التصنيف المختار لم يعد موجوداً"
            txs.update(old.copy(type = type, amount = amount, categoryName = cat, note = cleanNote, dateTime = dateTime))
        }
        null
    }

    suspend fun deleteTransaction(id: Long): Outcome = run("تم حذف العملية") {
        txs.deleteById(id)
        null
    }

    // ---------- الديون ----------

    suspend fun addDebt(direction: String, person: String, amount: Long, note: String, createdAt: Long): Outcome =
        run("تم حفظ الدين بنجاح") {
            if (direction != Kind.LENT && direction != Kind.BORROWED) return@run "نوع الدين غير صحيح"
            val name = Names.normalize(person)
            if (name.isEmpty()) return@run "اكتب اسم الشخص"
            if (name.length > 60) return@run "اسم الشخص طويل جداً"
            if (amount < 1 || amount > MAX_AMOUNT) return@run "المبلغ غير صالح"
            debts.insert(DebtEntity(0, direction, name, amount, note.trim(), createdAt))
            null
        }

    suspend fun deleteDebt(id: Long): Outcome = run("تم حذف الدين") {
        if (pays.forDebt(id).isNotEmpty()) return@run "لا يمكن حذف دين له دفعات"
        debts.deleteById(id)
        null
    }

    private suspend fun checkPayment(debtId: Long, amount: Long, dateTime: Long, exceptPaymentId: Long): String? {
        val debt = debts.getById(debtId) ?: return "الدين لم يعد موجوداً"
        if (amount < 1 || amount > MAX_AMOUNT) return "المبلغ غير صالح"
        val paid = pays.forDebt(debtId).filter { it.id != exceptPaymentId }.sumOf { it.amount }
        val remaining = debt.originalAmount - paid
        if (amount > remaining) return "المبلغ أكبر من المتبقي. المتبقي الصحيح هو ${Money.format(remaining)}"
        if (dateTime < debt.createdAt) return "تاريخ الدفعة لا يمكن أن يسبق تاريخ الدين"
        return null
    }

    suspend fun addPayment(debtId: Long, amount: Long, dateTime: Long): Outcome = run("تم تسجيل الدفعة") {
        checkPayment(debtId, amount, dateTime, -1)?.let { return@run it }
        pays.insert(DebtPaymentEntity(0, debtId, amount, dateTime))
        null
    }

    suspend fun updatePayment(paymentId: Long, amount: Long, dateTime: Long): Outcome = run("تم تعديل الدفعة") {
        val old = pays.getById(paymentId) ?: return@run "الدفعة لم تعد موجودة"
        checkPayment(old.debtId, amount, dateTime, paymentId)?.let { return@run it }
        pays.update(old.copy(amount = amount, dateTime = dateTime))
        null
    }

    suspend fun deletePayment(paymentId: Long): Outcome = run("تم إلغاء الدفعة") {
        pays.deleteById(paymentId)
        null
    }

    // ---------- النسخ الاحتياطي والحذف ----------

    suspend fun snapshot(): BackupJson.Data = db.withTransaction {
        BackupJson.Data(
            settings.get()?.openingBalance ?: 0L,
            categories.getAll(), txs.getAll(), debts.getAll(), pays.getAll()
        )
    }

    /** يستبدل كل البيانات بمحتوى النسخة داخل معاملة واحدة، ويتحقق من النتيجة قبل تثبيتها. */
    suspend fun replaceAll(data: BackupJson.Data, okMessage: String): Outcome = run(okMessage) {
        pays.clear(); debts.clear(); txs.clear(); categories.clear(); settings.clear()
        settings.upsert(SettingsEntity(1, data.openingBalance))
        categories.insertAll(data.categories)
        debts.insertAll(data.debts)
        txs.insertAll(data.transactions)
        pays.insertAll(data.payments)
        val ok = categories.getAll().size == data.categories.size &&
            txs.getAll().size == data.transactions.size &&
            debts.getAll().size == data.debts.size &&
            pays.getAll().size == data.payments.size &&
            settings.get()?.openingBalance == data.openingBalance
        if (!ok) throw IllegalStateException("restore verification failed")
        null
    }

    suspend fun deleteAll(): Outcome = run("تم حذف جميع البيانات") {
        pays.clear(); debts.clear(); txs.clear(); categories.clear(); settings.clear()
        val empty = categories.getAll().isEmpty() && txs.getAll().isEmpty() &&
            debts.getAll().isEmpty() && pays.getAll().isEmpty() && settings.get() == null
        if (!empty) throw IllegalStateException("delete verification failed")
        null
    }
}
