package com.hesabati.app.export

import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.hesabati.app.data.Kind
import com.hesabati.app.data.TransactionEntity
import com.hesabati.app.domain.Fmt
import com.hesabati.app.domain.Money
import com.hesabati.app.domain.PeriodReport
import java.io.ByteArrayOutputStream

object CsvExport {
    private val BOM = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())

    private fun cell(raw: String): String {
        var s = raw.replace("\r", " ").replace("\n", " ")
        // منع تفسير الخلية كصيغة في برامج الجداول
        if (s.isNotEmpty() && s[0] in "=+-@") s = "'$s"
        return "\"" + s.replace("\"", "\"\"") + "\""
    }

    /** عمليات الواردات والمصروفات العادية فقط؛ حركات الديون لا تدخل هذا الملف. */
    fun build(list: List<TransactionEntity>): ByteArray {
        val sb = StringBuilder()
        sb.append("التاريخ,الوقت,النوع,التصنيف,المبلغ (د.ع),البيان\r\n")
        for (t in list.sortedWith(compareBy<TransactionEntity> { it.dateTime }.thenBy { it.id })) {
            sb.append(cell(Fmt.date(t.dateTime))).append(',')
                .append(cell(Fmt.time(t.dateTime))).append(',')
                .append(cell(if (t.type == Kind.INCOME) "واردات" else "مصروفات")).append(',')
                .append(cell(t.categoryName)).append(',')
                .append(t.amount.toString()).append(',')
                .append(cell(t.note)).append("\r\n")
        }
        return BOM + sb.toString().toByteArray(Charsets.UTF_8)
    }
}

object ReportPdf {
    private const val W = 595
    private const val H = 842
    private const val M = 40f

    fun build(report: PeriodReport, typeLabel: String, periodLabel: String, generatedAt: String): ByteArray {
        val doc = PdfDocument()
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
        var c = page.canvas
        var y = M + 10f

        fun paint(size: Float, bold: Boolean, align: Paint.Align, color: Int = Color.BLACK) =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size
                typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                textAlign = align
                this.color = color
            }

        val titleP = paint(22f, true, Paint.Align.CENTER)
        val subP = paint(14f, false, Paint.Align.CENTER, Color.DKGRAY)
        val labelP = paint(14f, false, Paint.Align.RIGHT)
        val labelB = paint(14f, true, Paint.Align.RIGHT)
        val valueP = paint(14f, false, Paint.Align.LEFT)
        val valueB = paint(14f, true, Paint.Align.LEFT)
        val headP = paint(16f, true, Paint.Align.RIGHT, Color.rgb(27, 127, 92))
        val line = Paint().apply { color = Color.LTGRAY; strokeWidth = 0.8f }
        val right = W - M
        val left = M

        fun ensure(space: Float) {
            if (y + space > H - M) {
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
                c = page.canvas
                y = M + 10f
            }
        }

        fun heading(text: String) {
            ensure(40f)
            y += 14f
            c.drawText(text, right, y, headP)
            y += 8f
            c.drawLine(left, y, right, y, line)
            y += 8f
        }

        fun row(label: String, value: String, bold: Boolean = false) {
            ensure(26f)
            y += 18f
            c.drawText(label, right, y, if (bold) labelB else labelP)
            c.drawText(value, left, y, if (bold) valueB else valueP)
            y += 6f
            c.drawLine(left, y, right, y, line)
        }

        y += 14f
        c.drawText("حساباتي", W / 2f, y, titleP)
        y += 24f
        c.drawText("تقرير $typeLabel", W / 2f, y, subP)
        y += 20f
        c.drawText("الفترة: $periodLabel", W / 2f, y, subP)
        y += 20f
        c.drawText("تاريخ الإنشاء: $generatedAt", W / 2f, y, subP)

        heading("ملخص الفترة")
        row("الرصيد في بداية الفترة", Money.format(report.openingCash))
        row("إجمالي الواردات العادية", Money.format(report.income))
        row("إجمالي المصروفات العادية", Money.format(report.expense))
        row("صافي الحركة العادية", Money.format(report.netOrdinary), true)
        row("صافي الأثر النقدي للديون", Money.format(report.netDebtCash), true)
        row("الرصيد النقدي في نهاية الفترة", Money.format(report.closingCash), true)

        heading("حركات الديون خلال الفترة")
        row("أموال أقرضتها", Money.format(report.lent))
        row("أموال استردتها", Money.format(report.collected))
        row("أموال اقترضتها", Money.format(report.borrowed))
        row("أموال سددتها", Money.format(report.repaid))

        heading("الديون في نهاية الفترة")
        row("الديون المستحقة لك", Money.format(report.owedToMeAtEnd))
        row("الديون المستحقة عليك", Money.format(report.owedByMeAtEnd))

        heading("الواردات حسب التصنيف")
        if (report.incomeByCategory.isEmpty()) row("لا توجد واردات في هذه الفترة", "")
        report.incomeByCategory.forEach { row(it.first, Money.format(it.second)) }

        heading("المصروفات حسب التصنيف")
        if (report.expenseByCategory.isEmpty()) row("لا توجد مصروفات في هذه الفترة", "")
        report.expenseByCategory.forEach { row(it.first, Money.format(it.second)) }

        doc.finishPage(page)
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }
}
