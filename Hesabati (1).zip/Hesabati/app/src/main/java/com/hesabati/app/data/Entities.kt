package com.hesabati.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

object Kind {
    const val INCOME = "INCOME"
    const val EXPENSE = "EXPENSE"
    const val LENT = "LENT"          // دين لك: أقرضتَ شخصاً
    const val BORROWED = "BORROWED"  // دين عليك: اقترضتَ من شخص
}

/** أكبر مبلغ مسموح لعملية واحدة (أقل بكثير من حد Long لضمان سلامة الجمع). */
const val MAX_AMOUNT = 999_999_999_999L

@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val openingBalance: Long
)

@Entity(tableName = "categories", indices = [Index(value = ["name"], unique = true)])
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

/** اسم التصنيف يُحفظ نسخةً ثابتة داخل العملية، فلا يتأثر بتعديل التصنيف أو حذفه. */
@Entity(tableName = "transactions", indices = [Index(value = ["dateTime"])])
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val amount: Long,
    val categoryName: String,
    val note: String,
    val dateTime: Long
)

@Entity(tableName = "debts")
data class DebtEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val direction: String,
    val personName: String,
    val originalAmount: Long,
    val note: String,
    val createdAt: Long
)

@Entity(
    tableName = "debt_payments",
    foreignKeys = [
        ForeignKey(
            entity = DebtEntity::class,
            parentColumns = ["id"],
            childColumns = ["debtId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["debtId"])]
)
data class DebtPaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val debtId: Long,
    val amount: Long,
    val dateTime: Long
)
