package com.hesabati.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.hesabati.app.domain.Money

@Composable
fun HesabatiApp(vm: MainViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) {
        vm.messages.collect { snack.showSnackbar(it, duration = SnackbarDuration.Long) }
    }
    Box(Modifier.fillMaxSize()) {
        val s = state
        when {
            s == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
            !s.hasSettings -> SetupScreen(vm)
            else -> AppNav(vm, s)
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).padding(bottom = 90.dp))
    }
}

@Composable
private fun AppNav(vm: MainViewModel, s: AppState) {
    val nav = rememberNavController()
    NavHost(nav, startDestination = "main") {
        composable("main") { MainScreen(vm, s, nav) }
        composable("tx/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
            TransactionFormScreen(vm, s, it.arguments?.getLong("id") ?: 0L, nav)
        }
        composable("debt_add/{dir}") {
            DebtFormScreen(vm, it.arguments?.getString("dir") ?: "", nav)
        }
        composable("debt/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
            DebtDetailScreen(vm, s, it.arguments?.getLong("id") ?: 0L, nav)
        }
        composable("categories") { CategoriesScreen(vm, s, nav) }
    }
}

@Composable
private fun MainScreen(vm: MainViewModel, s: AppState, nav: NavHostController) {
    val tab by vm.selectedTab.collectAsStateWithLifecycle()
    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf(
                    "الرئيسية" to Icons.Default.Home,
                    "العمليات" to Icons.Default.Menu,
                    "الديون" to Icons.Default.Person,
                    "التقارير والإعدادات" to Icons.Default.Settings
                ).forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { vm.selectedTab.value = i },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 11.sp, maxLines = 1) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab == 0 || tab == 1) {
                ExtendedFloatingActionButton(onClick = { nav.navigate("tx/0") }) {
                    Text("+ إضافة عملية", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        floatingActionButtonPosition = FabPosition.Center
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeTab(s, nav)
                1 -> TransactionsTab(s, nav)
                2 -> DebtsTab(s, nav)
                else -> MoreTab(vm, s, nav)
            }
        }
    }
}

@Composable
fun SetupScreen(vm: MainViewModel) {
    val busy by vm.busy.collectAsStateWithLifecycle()
    var opening by remember { mutableStateOf("0") }
    var category by remember { mutableStateOf("") }
    var openingErr by remember { mutableStateOf<String?>(null) }
    var catErr by remember { mutableStateOf<String?>(null) }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
    ) {
        Text("مرحباً بك في حساباتي", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("خطوتان بسيطتان قبل البدء", color = MutedColor)
        AmountField(opening, { opening = it; openingErr = null }, "الرصيد الافتتاحي (د.ع) — يمكن أن يكون صفراً", error = openingErr)
        TextInput(category, { category = it; catErr = null }, "اسم أول تصنيف (مثال: طعام)", error = catErr)
        BigButton("ابدأ", {
            val parsed = Money.parse(opening, allowZero = true)
            openingErr = (parsed as? Money.ParseResult.Error)?.message
            catErr = if (category.isBlank()) "اكتب اسم التصنيف الأول" else null
            if (parsed is Money.ParseResult.Ok && catErr == null) {
                vm.perform(onFail = { catErr = it }) { vm.repo.completeSetup(parsed.value, category) }
            }
        }, enabled = !busy)
    }
}
