package com.hesabati.app.data

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class BackupException(message: String) : Exception(message)

/** صيغة النسخة الاحتياطية: ملف JSON واحد غير مشفر ذو إصدار محدد. */
object BackupJson {
    const val FORMAT = "hesabati-backup"
    const val VERSION = 1
    private const val BAD = "الملف تالف أو ليس نسخة احتياطية صالحة من «حساباتي»"

    data class Data(
        val openingBalance: Long,
        val categories: List<CategoryEntity>,
        val transactions: List<TransactionEntity>,
        val debts: List<DebtEntity>,
        val payments: List<DebtPaymentEntity>
    )

    fun toJson(d: Data, exportedAt: Long): String {
        val o = JSONObject()
        o.put("format", FORMAT)
        o.put("version", VERSION)
        o.put("exportedAt", exportedAt)
        o.put("openingBalance", d.openingBalance)
        o.put("categories", JSONArray().also { a ->
            d.categories.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name)) }
        })
        o.put("transactions", JSONArray().also { a ->
            d.transactions.forEach {
                a.put(
                    JSONObject().put("id", it.id).put("type", it.type).put("amount", it.amount)
                        .put("categoryName", it.categoryName).put("note", it.note).put("dateTime", it.dateTime)
                )
            }
        })
        o.put("debts", JSONArray().also { a ->
            d.debts.forEach {
                a.put(
                    JSONObject().put("id", it.id).put("direction", it.direction)
                        .put("personName", it.personName).put("originalAmount", it.originalAmount)
                        .put("note", it.note).put("createdAt", it.createdAt)
                )
            }
        })
        o.put("payments", JSONArray().also { a ->
            d.payments.forEach {
                a.put(
                    JSONObject().put("id", it.id).put("debtId", it.debtId)
                        .put("amount", it.amount).put("dateTime", it.dateTime)
                )
            }
        })
        return o.toString(2)
    }

    private fun JSONObject.long(key: String): Long {
        val v = get(key)
        return when (v) {
            is Int -> v.toLong()
            is Long -> v
            else -> throw BackupException(BAD)
        }
    }

    private fun JSONObject.str(key: String): String {
        val v = get(key)
        if (v !is String) throw BackupException(BAD)
        return v
    }

    /** يقرأ الملف ويتحقق منه كاملاً دون أي تغيير للبيانات الحالية. */
    fun parse(text: String): Data {
        try {
            val o = JSONObject(text)
            if (o.str("format") != FORMAT) throw BackupException(BAD)
            val version = o.long("version")
            if (version > VERSION) {
                throw BackupException("إصدار هذه النسخة أحدث من إصدار التطبيق، حدّث التطبيق ثم أعد المحاولة")
            }
            if (version < 1) throw BackupException(BAD)

            val categories = o.getJSONArray("categories").let { a ->
                (0 until a.length()).map { i -> a.getJSONObject(i).let { CategoryEntity(it.long("id"), it.str("name")) } }
            }
            val transactions = o.getJSONArray("transactions").let { a ->
                (0 until a.length()).map { i ->
                    a.getJSONObject(i).let {
                        TransactionEntity(
                            it.long("id"), it.str("type"), it.long("amount"),
                            it.str("categoryName"), it.str("note"), it.long("dateTime")
                        )
                    }
                }
            }
            val debts = o.getJSONArray("debts").let { a ->
                (0 until a.length()).map { i ->
                    a.getJSONObject(i).let {
                        DebtEntity(
                            it.long("id"), it.str("direction"), it.str("personName"),
                            it.long("originalAmount"), it.str("note"), it.long("createdAt")
                        )
                    }
                }
            }
            val payments = o.getJSONArray("payments").let { a ->
                (0 until a.length()).map { i ->
                    a.getJSONObject(i).let {
                        DebtPaymentEntity(it.long("id"), it.long("debtId"), it.long("amount"), it.long("dateTime"))
                    }
                }
            }
            val data = Data(o.long("openingBalance"), categories, transactions, debts, payments)
            validate(data)
            return data
        } catch (e: JSONException) {
            throw BackupException(BAD)
        }
    }

    private fun validate(d: Data) {
        if (d.openingBalance < 0 || d.openingBalance > MAX_AMOUNT) throw BackupException(BAD)
        if (d.categories.any { it.id <= 0 || it.name.isBlank() }) throw BackupException(BAD)
        if (d.categories.map { it.id }.toSet().size != d.categories.size) throw BackupException(BAD)
        if (d.categories.map { it.name }.toSet().size != d.categories.size) throw BackupException(BAD)
        if (d.transactions.any {
                it.id <= 0 || it.amount !in 1..MAX_AMOUNT || it.categoryName.isBlank() ||
                    (it.type != Kind.INCOME && it.type != Kind.EXPENSE)
            }
        ) throw BackupException(BAD)
        if (d.transactions.map { it.id }.toSet().size != d.transactions.size) throw BackupException(BAD)
        if (d.debts.any {
                it.id <= 0 || it.originalAmount !in 1..MAX_AMOUNT || it.personName.isBlank() ||
                    (it.direction != Kind.LENT && it.direction != Kind.BORROWED)
            }
        ) throw BackupException(BAD)
        if (d.debts.map { it.id }.toSet().size != d.debts.size) throw BackupException(BAD)
        if (d.payments.any { it.id <= 0 || it.amount !in 1..MAX_AMOUNT }) throw BackupException(BAD)
        if (d.payments.map { it.id }.toSet().size != d.payments.size) throw BackupException(BAD)
        val debtById = d.debts.associateBy { it.id }
        if (d.payments.any { debtById[it.debtId] == null }) throw BackupException(BAD)
        for ((debtId, list) in d.payments.groupBy { it.debtId }) {
            val total = list.fold(0L) { a, p -> a + p.amount }
            if (total > debtById.getValue(debtId).originalAmount) throw BackupException(BAD)
        }
    }
}
