package com.hesabati.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.hesabati.app.data.Kind
import com.hesabati.app.data.TransactionEntity
import com.hesabati.app.domain.FinanceCalculator
import com.hesabati.app.domain.Money
import com.hesabati.app.domain.Names
import com.hesabati.app.domain.TxFilter
import com.hesabati.app.domain.filterTransactions
import java.time.Instant
import java.time.ZoneId

@Composable
fun HomeTab(s: AppState, nav: NavHostController) {
    val summary = remember(s.ledger) { FinanceCalculator.summary(s.ledger) }
    val recent = remember(s.ledger) { filterTransactions(s.ledger.transactions, TxFilter()).take(5) }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
    ) {
        item { StatCard("النقد المتوفر حالياً", summary.cash, Modifier.fillMaxWidth(), big = true) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("ديون لك عند الآخرين", summary.owedToMe, Modifier.weight(1f))
                StatCard("ديون عليك للآخرين", summary.owedByMe, Modifier.weight(1f))
            }
        }
        item { StatCard("صافي الوضع المالي", summary.net, Modifier.fillMaxWidth()) }
        item { Text("آخر العمليات", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
        if (recent.isEmpty()) item { Text("لا توجد عمليات بعد. اضغط «+ إضافة عملية» للبدء", color = MutedColor) }
        items(recent, key = { it.id }) { t -> TxRow(t) { nav.navigate("tx/${t.id}") } }
    }
}

@Composable
fun TransactionsTab(s: AppState, nav: NavHostController) {
    val zone = ZoneId.systemDefault()
    var showFilters by remember { mutableStateOf(false) }
    var type by remember { mutableStateOf<String?>(null) }
    var cat by remember { mutableStateOf<String?>(null) }
    var from by remember { mutableStateOf<Long?>(null) }
    var to by remember { mutableStateOf<Long?>(null) }
    var minT by remember { mutableStateOf("") }
    var maxT by remember { mutableStateOf("") }
    var catMenu by remember { mutableStateOf(false) }

    fun parseOpt(t: String): Pair<Long?, String?> {
        if (t.isBlank()) return null to null
        return when (val r = Money.parse(t, allowZero = true)) {
            is Money.ParseResult.Ok -> r.value to null
            is Money.ParseResult.Error -> null to r.message
        }
    }
    val (minV, minErr) = parseOpt(minT)
    val (maxV, maxErr) = parseOpt(maxT)
    val toExclusive = to?.let {
        Instant.ofEpochMilli(it).atZone(zone).toLocalDate().plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
    }
    val filter = TxFilter(type, cat, from, toExclusive, minV, maxV)
    val list = remember(s.ledger.transactions, filter) { filterTransactions(s.ledger.transactions, filter) }
    val catNames = remember(s.ledger.transactions, s.categories) {
        (s.categories.map { it.name } + s.ledger.transactions.map { it.categoryName }).distinct().sorted()
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("العمليات", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { showFilters = !showFilters }) {
                    Text(if (showFilters) "إخفاء البحث" else if (filter.isActive) "بحث وتصفية (مفعّل)" else "بحث وتصفية")
                }
            }
        }
        if (showFilters) item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = type == null, onClick = { type = null }, label = { Text("الكل") })
                        FilterChip(selected = type == Kind.INCOME, onClick = { type = Kind.INCOME }, label = { Text("واردات") })
                        FilterChip(selected = type == Kind.EXPENSE, onClick = { type = Kind.EXPENSE }, label = { Text("مصروفات") })
                    }
                    Box {
                        OutlinedButton(onClick = { catMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(cat ?: "كل التصنيفات")
                        }
                        DropdownMenu(expanded = catMenu, onDismissRequest = { catMenu = false }) {
                            DropdownMenuItem(text = { Text("كل التصنيفات") }, onClick = { cat = null; catMenu = false })
                            catNames.forEach { n -> DropdownMenuItem(text = { Text(n) }, onClick = { cat = n; catMenu = false }) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DateOnlyField("من تاريخ", from, { from = it }, Modifier.weight(1f))
                        DateOnlyField("إلى تاريخ", to, { to = it }, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AmountField(minT, { minT = it }, "من مبلغ", Modifier.weight(1f), minErr)
                        AmountField(maxT, { maxT = it }, "إلى مبلغ", Modifier.weight(1f), maxErr)
                    }
                    SoftButton("مسح عوامل البحث", {
                        type = null; cat = null; from = null; to = null; minT = ""; maxT = ""
                    })
                }
            }
        }
        item { Text("عدد العمليات: ${list.size}", color = MutedColor, fontSize = 13.sp) }
        if (list.isEmpty()) item {
            Text(if (filter.isActive) "لا توجد عمليات تطابق شروط البحث" else "لا توجد عمليات بعد", color = MutedColor)
        }
        items(list, key = { it.id }) { t -> TxRow(t) { nav.navigate("tx/${t.id}") } }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TransactionFormScreen(vm: MainViewModel, s: AppState, id: Long, nav: NavHostController) {
    val existing = remember(id) { s.ledger.transactions.find { it.id == id } }
    if (id != 0L && existing == null) {
        SubScreen("العملية", { nav.popBackStack() }) { Text("لم تعد هذه العملية موجودة") }
        return
    }
    val busy by vm.busy.collectAsState()
    var type by remember { mutableStateOf(existing?.type ?: Kind.EXPENSE) }
    var amountText by remember { mutableStateOf(existing?.amount?.toString() ?: "") }
    var category by remember { mutableStateOf(existing?.categoryName) }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var time by remember { mutableStateOf(existing?.dateTime ?: System.currentTimeMillis()) }
    var amountError by remember { mutableStateOf<String?>(null) }
    var categoryError by remember { mutableStateOf<String?>(null) }
    var warning by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var addCategory by remember { mutableStateOf(false) }

    fun doSave(amount: Long) {
        val cat = category ?: return
        vm.perform(onSuccess = {
            vm.selectedTab.value = 0
            nav.popBackStack("main", false)
        }) { vm.repo.saveTransaction(id, type, amount, cat, note, time) }
    }

    fun trySave() {
        if (busy) return
        val parsed = Money.parse(amountText)
        amountError = (parsed as? Money.ParseResult.Error)?.message
        categoryError = if (category.isNullOrBlank()) "اختر التصنيف أولاً" else null
        if (parsed !is Money.ParseResult.Ok || categoryError != null) return
        val amount = parsed.value
        if (type == Kind.EXPENSE) {
            val candidate = s.ledger.copy(
                transactions = s.ledger.transactions.filter { it.id != id } +
                    TransactionEntity(id, type, amount, category!!, note, time)
            )
            val cash = try {
                FinanceCalculator.summary(candidate).cash
            } catch (e: ArithmeticException) {
                amountError = "المبلغ كبير جداً"; return
            }
            if (cash < 0) {
                warning = "هذا المصروف أكبر من النقد المتوفر، وسيصبح الرصيد ${Money.format(cash)}. هل تريد تسجيله؟"
                return
            }
        }
        doSave(amount)
    }

    SubScreen(if (id == 0L) "إضافة عملية" else "تعديل عملية", { nav.popBackStack() }) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(
                selected = type == Kind.EXPENSE, onClick = { type = Kind.EXPENSE },
                label = { Text("مصروفات", fontSize = 16.sp) }, modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = type == Kind.INCOME, onClick = { type = Kind.INCOME },
                label = { Text("واردات", fontSize = 16.sp) }, modifier = Modifier.weight(1f)
            )
        }
        AmountField(amountText, { amountText = it; amountError = null }, "المبلغ (د.ع)", error = amountError)

        Text("التصنيف", fontSize = 14.sp, color = MutedColor)
        val chips = buildList {
            addAll(s.categories.map { it.name })
            val cur = category
            if (cur != null && cur !in this) add(cur)
        }
        if (s.categories.isEmpty()) Text("لا توجد تصنيفات. أنشئ تصنيفاً أولاً", color = RedColor)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            chips.forEach { n ->
                FilterChip(selected = category == n, onClick = { category = n; categoryError = null }, label = { Text(n) })
            }
            AssistChip(onClick = { addCategory = true }, label = { Text("+ تصنيف جديد") })
        }
        categoryError?.let { Text(it, color = RedColor, fontSize = 13.sp) }

        TextInput(note, { note = it }, "البيان (اختياري)", singleLine = false)
        DateTimeField(time, { time = it }, "التاريخ والوقت")
        BigButton("حفظ", { trySave() }, enabled = !busy)
        if (existing != null) SoftButton("حذف العملية", { confirmDelete = true }, danger = true)
    }

    warning?.let { w ->
        ConfirmDialog("تنبيه", w, "نعم، سجّل المصروف", {
            warning = null
            (Money.parse(amountText) as? Money.ParseResult.Ok)?.let { doSave(it.value) }
        }, { warning = null }, danger = true)
    }
    if (confirmDelete) {
        ConfirmDialog("حذف العملية", "هل أنت متأكد من حذف هذه العملية؟ لا يمكن التراجع عن الحذف.", "حذف", {
            confirmDelete = false
            vm.perform(onSuccess = { nav.popBackStack("main", false) }) { vm.repo.deleteTransaction(id) }
        }, { confirmDelete = false }, danger = true)
    }
    if (addCategory) {
        var name by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { addCategory = false },
            title = { Text("تصنيف جديد") },
            text = { TextInput(name, { name = it; err = null }, "اسم التصنيف", error = err) },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    vm.perform(onFail = { err = it }, onSuccess = {
                        category = Names.normalize(name); categoryError = null; addCategory = false
                    }) { vm.repo.addCategory(name) }
                }) { Text("إضافة") }
            },
            dismissButton = { TextButton(onClick = { addCategory = false }) { Text("إلغاء") } }
        )
    }
}
