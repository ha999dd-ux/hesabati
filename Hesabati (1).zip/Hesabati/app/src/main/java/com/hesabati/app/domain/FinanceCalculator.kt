package com.hesabati.app.domain

import com.hesabati.app.data.DebtEntity
import com.hesabati.app.data.DebtPaymentEntity
import com.hesabati.app.data.Kind
import com.hesabati.app.data.TransactionEntity

/** كل بيانات الحسابات المالية. جميع الأرقام تُشتق منها فقط ولا تُحفظ نتائج جاهزة. */
data class Ledger(
    val openingBalance: Long,
    val transactions: List<TransactionEntity>,
    val debts: List<DebtEntity>,
    val payments: List<DebtPaymentEntity>
)

data class Summary(val cash: Long, val owedToMe: Long, val owedByMe: Long) {
    val net: Long get() = cash + owedToMe - owedByMe
}

data class DebtView(val debt: DebtEntity, val paid: Long, val remaining: Long) {
    val isPaid: Boolean get() = remaining == 0L
}

data class PeriodReport(
    val start: Long,
    val endExclusive: Long,
    val openingCash: Long,
    val income: Long,
    val expense: Long,
    val netOrdinary: Long,
    val lent: Long,
    val collected: Long,
    val borrowed: Long,
    val repaid: Long,
    val netDebtCash: Long,
    val closingCash: Long,
    val owedToMeAtEnd: Long,
    val owedByMeAtEnd: Long,
    val incomeByCategory: List<Pair<String, Long>>,
    val expenseByCategory: List<Pair<String, Long>>
)

/**
 * المصدر الوحيد لكل القواعد الحسابية في التطبيق.
 * يستخدم الجمع الآمن (addExact) فيرمي ArithmeticException عند تجاوز الحدود بدلاً من إعطاء رقم خاطئ.
 */
object FinanceCalculator {

    private fun inRange(t: Long, before: Long?) = before == null || t < before

    /** النقد المتوفر قبل اللحظة [before] (أو الآن إذا كانت null). */
    fun cashAt(l: Ledger, before: Long?): Long {
        var cash = l.openingBalance
        for (t in l.transactions) {
            if (!inRange(t.dateTime, before)) continue
            cash = if (t.type == Kind.INCOME) Math.addExact(cash, t.amount) else Math.subtractExact(cash, t.amount)
        }
        for (d in l.debts) {
            if (!inRange(d.createdAt, before)) continue
            cash = if (d.direction == Kind.LENT) Math.subtractExact(cash, d.originalAmount)
            else Math.addExact(cash, d.originalAmount)
        }
        val direction = l.debts.associate { it.id to it.direction }
        for (p in l.payments) {
            val dir = direction[p.debtId] ?: continue
            if (!inRange(p.dateTime, before)) continue
            cash = if (dir == Kind.LENT) Math.addExact(cash, p.amount) else Math.subtractExact(cash, p.amount)
        }
        return cash
    }

    fun paidOf(l: Ledger, debtId: Long, before: Long? = null): Long {
        var sum = 0L
        for (p in l.payments) if (p.debtId == debtId && inRange(p.dateTime, before)) sum = Math.addExact(sum, p.amount)
        return sum
    }

    fun debtViews(l: Ledger): List<DebtView> = l.debts.map { d ->
        val paid = paidOf(l, d.id)
        DebtView(d, paid, d.originalAmount - paid)
    }

    fun owedAt(l: Ledger, direction: String, before: Long?): Long {
        var sum = 0L
        for (d in l.debts) {
            if (d.direction != direction || !inRange(d.createdAt, before)) continue
            sum = Math.addExact(sum, d.originalAmount - paidOf(l, d.id, before))
        }
        return sum
    }

    fun summary(l: Ledger): Summary =
        Summary(cashAt(l, null), owedAt(l, Kind.LENT, null), owedAt(l, Kind.BORROWED, null))

    fun report(l: Ledger, start: Long, endExclusive: Long): PeriodReport {
        fun inPeriod(t: Long) = t >= start && t < endExclusive
        var income = 0L
        var expense = 0L
        val inc = linkedMapOf<String, Long>()
        val exp = linkedMapOf<String, Long>()
        for (t in l.transactions) {
            if (!inPeriod(t.dateTime)) continue
            if (t.type == Kind.INCOME) {
                income = Math.addExact(income, t.amount)
                inc[t.categoryName] = Math.addExact(inc[t.categoryName] ?: 0L, t.amount)
            } else {
                expense = Math.addExact(expense, t.amount)
                exp[t.categoryName] = Math.addExact(exp[t.categoryName] ?: 0L, t.amount)
            }
        }
        var lent = 0L
        var borrowed = 0L
        for (d in l.debts) {
            if (!inPeriod(d.createdAt)) continue
            if (d.direction == Kind.LENT) lent = Math.addExact(lent, d.originalAmount)
            else borrowed = Math.addExact(borrowed, d.originalAmount)
        }
        var collected = 0L
        var repaid = 0L
        val direction = l.debts.associate { it.id to it.direction }
        for (p in l.payments) {
            val dir = direction[p.debtId] ?: continue
            if (!inPeriod(p.dateTime)) continue
            if (dir == Kind.LENT) collected = Math.addExact(collected, p.amount)
            else repaid = Math.addExact(repaid, p.amount)
        }
        val netDebtCash = collected - lent + borrowed - repaid
        return PeriodReport(
            start = start,
            endExclusive = endExclusive,
            openingCash = cashAt(l, start),
            income = income,
            expense = expense,
            netOrdinary = income - expense,
            lent = lent,
            collected = collected,
            borrowed = borrowed,
            repaid = repaid,
            netDebtCash = netDebtCash,
            closingCash = cashAt(l, endExclusive),
            owedToMeAtEnd = owedAt(l, Kind.LENT, endExclusive),
            owedByMeAtEnd = owedAt(l, Kind.BORROWED, endExclusive),
            incomeByCategory = inc.entries.map { it.key to it.value }.sortedByDescending { it.second },
            expenseByCategory = exp.entries.map { it.key to it.value }.sortedByDescending { it.second }
        )
    }
}

/** شروط البحث؛ تُطبّق جميعها معاً. */
data class TxFilter(
    val type: String? = null,
    val categoryName: String? = null,
    val fromMillis: Long? = null,
    val toMillisExclusive: Long? = null,
    val minAmount: Long? = null,
    val maxAmount: Long? = null
) {
    val isActive: Boolean
        get() = type != null || categoryName != null || fromMillis != null ||
            toMillisExclusive != null || minAmount != null || maxAmount != null
}

fun filterTransactions(list: List<TransactionEntity>, f: TxFilter): List<TransactionEntity> =
    list.filter { t ->
        (f.type == null || t.type == f.type) &&
            (f.categoryName == null || t.categoryName == f.categoryName) &&
            (f.fromMillis == null || t.dateTime >= f.fromMillis) &&
            (f.toMillisExclusive == null || t.dateTime < f.toMillisExclusive) &&
            (f.minAmount == null || t.amount >= f.minAmount) &&
            (f.maxAmount == null || t.amount <= f.maxAmount)
    }.sortedWith(compareByDescending<TransactionEntity> { it.dateTime }.thenByDescending { it.id })
