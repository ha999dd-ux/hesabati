package com.hesabati.app.domain

import com.hesabati.app.data.MAX_AMOUNT
import java.util.Locale

object Money {
    const val CURRENCY = "د.ع"

    fun format(value: Long): String =
        String.format(Locale.US, "%,d", value) + " " + CURRENCY

    sealed interface ParseResult {
        data class Ok(val value: Long) : ParseResult
        data class Error(val message: String) : ParseResult
    }

    /** يحوّل نص المبلغ إلى عدد صحيح. يقبل الأرقام العربية وفواصل الآلاف، ويرفض الكسور والصفر والسالب. */
    fun parse(raw: String, allowZero: Boolean = false): ParseResult {
        val sb = StringBuilder()
        for (ch in raw) {
            when (ch) {
                in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                ' ', ',', '٬', '\u200E', '\u200F', '\u00A0' -> Unit
                else -> sb.append(ch)
            }
        }
        val s = sb.toString()
        if (s.isEmpty()) return ParseResult.Error("أدخل المبلغ")
        if (s.contains('.') || s.contains('٫') || s.contains('/')) {
            return ParseResult.Error("المبلغ يجب أن يكون عدداً صحيحاً بدون كسور")
        }
        if (s.startsWith("-")) {
            return ParseResult.Error(
                if (s.length > 1 && s.drop(1).all { it in '0'..'9' }) "المبلغ لا يمكن أن يكون سالباً"
                else "المبلغ غير صالح، استخدم الأرقام فقط"
            )
        }
        if (!s.all { it in '0'..'9' }) return ParseResult.Error("المبلغ غير صالح، استخدم الأرقام فقط")
        val trimmed = s.trimStart('0')
        if (trimmed.length > 13) return ParseResult.Error("المبلغ كبير جداً")
        val v = if (trimmed.isEmpty()) 0L else trimmed.toLong()
        if (v > MAX_AMOUNT) return ParseResult.Error("المبلغ كبير جداً")
        if (v == 0L && !allowZero) return ParseResult.Error("يجب أن يكون المبلغ أكبر من صفر")
        return ParseResult.Ok(v)
    }
}

object Names {
    const val MAX_LEN = 40
    fun normalize(s: String): String = s.trim().replace(Regex("\\s+"), " ")
}
