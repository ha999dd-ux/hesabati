package com.hesabati.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hesabati.app.data.Kind
import com.hesabati.app.data.TransactionEntity
import com.hesabati.app.domain.Fmt
import com.hesabati.app.domain.Money
import java.time.Instant
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset

val GreenColor = Color(0xFF1B7F5C)
val RedColor = Color(0xFFC0392B)
val MutedColor = Color(0xFF52606D)

fun moneyColor(v: Long): Color = if (v < 0) RedColor else Color(0xFF1F2933)

@Composable
fun BigButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().heightIn(min = 56.dp),
        shape = RoundedCornerShape(14.dp)
    ) { Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun SoftButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, danger: Boolean = false, enabled: Boolean = true) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().heightIn(min = 52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = if (danger) ButtonDefaults.outlinedButtonColors(contentColor = RedColor) else ButtonDefaults.outlinedButtonColors()
    ) { Text(text, fontSize = 16.sp) }
}

@Composable
fun StatCard(label: String, value: Long, modifier: Modifier = Modifier, big: Boolean = false) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, fontSize = 14.sp, color = MutedColor)
            Spacer(Modifier.height(4.dp))
            Text(
                Money.format(value),
                fontSize = if (big) 30.sp else 20.sp,
                fontWeight = FontWeight.Bold,
                color = moneyColor(value)
            )
        }
    }
}

@Composable
fun TextInput(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, error: String? = null, singleLine: Boolean = true) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        isError = error != null,
        supportingText = if (error != null) ({ Text(error) }) else null,
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun AmountField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, error: String? = null) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        isError = error != null,
        supportingText = if (error != null) ({ Text(error) }) else null,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    danger: Boolean = false
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(text) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(confirmLabel, color = if (danger) RedColor else MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateTimeField(millis: Long, onChange: (Long) -> Unit, label: String) {
    val zone = ZoneId.systemDefault()
    val cur = Instant.ofEpochMilli(millis).atZone(zone).toLocalDateTime()
    var showDate by remember { mutableStateOf(false) }
    var showTime by remember { mutableStateOf(false) }
    Column {
        Text(label, fontSize = 14.sp, color = MutedColor)
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { showDate = true }, modifier = Modifier.weight(1f)) { Text(Fmt.date(millis)) }
            OutlinedButton(onClick = { showTime = true }, modifier = Modifier.weight(1f)) { Text(Fmt.time(millis)) }
        }
    }
    if (showDate) {
        val st = rememberDatePickerState(
            initialSelectedDateMillis = cur.toLocalDate().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showDate = false },
            confirmButton = {
                TextButton(onClick = {
                    st.selectedDateMillis?.let { m ->
                        val d = Instant.ofEpochMilli(m).atZone(ZoneOffset.UTC).toLocalDate()
                        onChange(LocalDateTime.of(d, cur.toLocalTime()).atZone(zone).toInstant().toEpochMilli())
                    }
                    showDate = false
                }) { Text("موافق") }
            },
            dismissButton = { TextButton(onClick = { showDate = false }) { Text("إلغاء") } }
        ) { DatePicker(state = st) }
    }
    if (showTime) {
        val ts = rememberTimePickerState(initialHour = cur.hour, initialMinute = cur.minute, is24Hour = true)
        AlertDialog(
            onDismissRequest = { showTime = false },
            confirmButton = {
                TextButton(onClick = {
                    onChange(
                        LocalDateTime.of(cur.toLocalDate(), LocalTime.of(ts.hour, ts.minute))
                            .atZone(zone).toInstant().toEpochMilli()
                    )
                    showTime = false
                }) { Text("موافق") }
            },
            dismissButton = { TextButton(onClick = { showTime = false }) { Text("إلغاء") } },
            text = { TimePicker(state = ts) }
        )
    }
}

/** حقل تاريخ اختياري (للبحث). القيمة هي بداية اليوم المختار. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateOnlyField(label: String, millis: Long?, onChange: (Long?) -> Unit, modifier: Modifier = Modifier) {
    val zone = ZoneId.systemDefault()
    var show by remember { mutableStateOf(false) }
    Column(modifier) {
        Text(label, fontSize = 13.sp, color = MutedColor)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { show = true }, modifier = Modifier.weight(1f)) {
                Text(if (millis == null) "اختر" else Fmt.date(millis))
            }
            if (millis != null) TextButton(onClick = { onChange(null) }) { Text("مسح") }
        }
    }
    if (show) {
        val st = rememberDatePickerState(
            initialSelectedDateMillis = (millis?.let { Instant.ofEpochMilli(it).atZone(zone).toLocalDate() }
                ?: java.time.LocalDate.now(zone)).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton(onClick = {
                    st.selectedDateMillis?.let { m ->
                        val d = Instant.ofEpochMilli(m).atZone(ZoneOffset.UTC).toLocalDate()
                        onChange(Fmt.startOfDay(d, zone))
                    }
                    show = false
                }) { Text("موافق") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("إلغاء") } }
        ) { DatePicker(state = st) }
    }
}

@Composable
fun TxRow(t: TransactionEntity, onClick: () -> Unit) {
    val income = t.type == Kind.INCOME
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.categoryName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (t.note.isNotBlank()) Text(t.note, fontSize = 13.sp, color = MutedColor, maxLines = 1)
                Text(Fmt.dateTime(t.dateTime), fontSize = 12.sp, color = MutedColor)
            }
            Text(
                (if (income) "+" else "-") + Money.format(t.amount),
                color = if (income) GreenColor else RedColor,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubScreen(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع") }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
fun InfoRow(label: String, value: String, valueColor: Color = Color(0xFF1F2933), bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 15.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(value, color = valueColor, fontSize = 15.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}
