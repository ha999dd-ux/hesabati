package com.hesabati.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val scheme = lightColorScheme(
    primary = Color(0xFF1B7F5C),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD7EFE6),
    onPrimaryContainer = Color(0xFF0B3D2C),
    secondary = Color(0xFF3E5C76),
    background = Color(0xFFF6F8F7),
    surface = Color(0xFFF6F8F7),
    onSurface = Color(0xFF1F2933),
    error = Color(0xFFC0392B)
)

@Composable
fun HesabatiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
