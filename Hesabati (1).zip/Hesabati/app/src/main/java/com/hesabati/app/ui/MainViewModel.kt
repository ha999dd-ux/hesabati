package com.hesabati.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hesabati.app.data.AppDatabase
import com.hesabati.app.data.BackupException
import com.hesabati.app.data.BackupJson
import com.hesabati.app.data.CategoryEntity
import com.hesabati.app.data.Outcome
import com.hesabati.app.data.Repository
import com.hesabati.app.domain.FinanceCalculator
import com.hesabati.app.domain.Fmt
import com.hesabati.app.domain.Ledger
import com.hesabati.app.domain.PeriodType
import com.hesabati.app.domain.Periods
import com.hesabati.app.domain.filterTransactions
import com.hesabati.app.domain.TxFilter
import com.hesabati.app.export.CsvExport
import com.hesabati.app.export.ReportPdf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.ZoneId

data class AppState(
    val hasSettings: Boolean,
    val ledger: Ledger,
    val categories: List<CategoryEntity>
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val repo = Repository(AppDatabase.get(app))

    val state: StateFlow<AppState?> = combine(
        repo.settingsFlow, repo.categoriesFlow, repo.transactionsFlow, repo.debtsFlow, repo.paymentsFlow
    ) { settings, cats, txs, debts, pays ->
        AppState(settings != null, Ledger(settings?.openingBalance ?: 0L, txs, debts, pays), cats)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val busy = MutableStateFlow(false)
    val selectedTab = MutableStateFlow(0)
    val pendingRestore = MutableStateFlow<BackupJson.Data?>(null)

    /** ينفّذ عملية واحدة في كل مرة؛ يتجاهل الضغطات المتكررة أثناء التنفيذ ولا يعرض نجاحاً إلا بعد نجاحها فعلاً. */
    fun perform(
        onFail: (String) -> Unit = {},
        onSuccess: () -> Unit = {},
        block: suspend () -> Outcome
    ) {
        if (busy.value) return
        busy.value = true
        viewModelScope.launch {
            try {
                when (val o = block()) {
                    is Outcome.Ok -> { messages.tryEmit(o.message); onSuccess() }
                    is Outcome.Fail -> { messages.tryEmit(o.message); onFail(o.message) }
                }
            } finally {
                busy.value = false
            }
        }
    }

    // ---------- أدوات الملفات ----------

    private suspend fun readAll(uri: Uri): ByteArray? = withContext(Dispatchers.IO) {
        try {
            getApplication<Application>().contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        }
    }

    /** يكتب الملف ثم يعيد قراءته للتأكد من أن المحتوى المكتوب مطابق تماماً. */
    private suspend fun writeAndVerify(uri: Uri, bytes: ByteArray): Boolean = withContext(Dispatchers.IO) {
        try {
            val cr = getApplication<Application>().contentResolver
            val stream = cr.openOutputStream(uri, "wt")
            if (stream == null) {
                false
            } else {
                stream.use { it.write(bytes); it.flush() }
                val back = cr.openInputStream(uri)?.use { it.readBytes() }
                back != null && back.contentEquals(bytes)
            }
        } catch (e: Exception) {
            false
        }
    }

    // ---------- النسخ الاحتياطي ----------

    fun createBackup(uri: Uri) = perform {
        try {
            val data = repo.snapshot()
            val bytes = BackupJson.toJson(data, System.currentTimeMillis()).toByteArray(Charsets.UTF_8)
            if (writeAndVerify(uri, bytes)) Outcome.Ok("تم إنشاء النسخة الاحتياطية بنجاح")
            else Outcome.Fail("فشل حفظ النسخة الاحتياطية. لم يتم إنشاء أي نسخة")
        } catch (e: Exception) {
            Outcome.Fail("فشل حفظ النسخة الاحتياطية. لم يتم إنشاء أي نسخة")
        }
    }

    /** الخطوة الأولى: قراءة الملف والتحقق منه فقط، دون تغيير أي بيانات. */
    fun prepareRestore(uri: Uri) {
        viewModelScope.launch {
            val bytes = readAll(uri)
            if (bytes == null || bytes.size > 100 * 1024 * 1024) {
                messages.tryEmit("تعذر قراءة الملف. البيانات الحالية لم تتغير")
                return@launch
            }
            try {
                pendingRestore.value = BackupJson.parse(String(bytes, Charsets.UTF_8))
            } catch (e: BackupException) {
                messages.tryEmit((e.message ?: "الملف غير صالح") + ". البيانات الحالية لم تتغير")
            } catch (e: Exception) {
                messages.tryEmit("الملف تالف أو غير متوافق. البيانات الحالية لم تتغير")
            }
        }
    }

    fun cancelRestore() { pendingRestore.value = null }

    /** الخطوة الثانية بعد تأكيد المستخدم: نسخة أمان تلقائية ثم الاستبدال داخل معاملة واحدة. */
    fun confirmRestore() {
        val data = pendingRestore.value ?: return
        perform(
            onFail = { pendingRestore.value = null },
            onSuccess = { pendingRestore.value = null; selectedTab.value = 0 }
        ) {
            try {
                val safetyOk = withContext(Dispatchers.IO) {
                    val bytes = BackupJson.toJson(repo.snapshot(), System.currentTimeMillis()).toByteArray(Charsets.UTF_8)
                    val dir = File(getApplication<Application>().filesDir, "safety").apply { mkdirs() }
                    val file = File(dir, "safety_" + System.currentTimeMillis() + ".json")
                    file.writeBytes(bytes)
                    file.length() == bytes.size.toLong()
                }
                if (!safetyOk) Outcome.Fail("تعذر إنشاء نسخة الأمان، لذلك لم تتم الاستعادة")
                else repo.replaceAll(data, "تمت استعادة النسخة بنجاح. حُفظت نسخة أمان من بياناتك السابقة داخل التطبيق")
            } catch (e: Exception) {
                Outcome.Fail("تعذر إنشاء نسخة الأمان، لذلك لم تتم الاستعادة")
            }
        }
    }

    // ---------- تصدير التقارير ----------

    private fun reportFor(type: PeriodType, anchor: LocalDate) =
        Periods.range(type, anchor, ZoneId.systemDefault()).let { (s, e) ->
            FinanceCalculator.report(state.value!!.ledger, s, e)
        }

    fun exportPdf(uri: Uri, type: PeriodType, anchor: LocalDate) = perform {
        try {
            val report = reportFor(type, anchor)
            val bytes = withContext(Dispatchers.Default) {
                ReportPdf.build(report, type.label, Periods.label(type, anchor), Fmt.dateTime(System.currentTimeMillis()))
            }
            if (writeAndVerify(uri, bytes)) Outcome.Ok("تم تصدير ملف PDF بنجاح")
            else Outcome.Fail("فشل تصدير ملف PDF")
        } catch (e: Exception) {
            Outcome.Fail("فشل تصدير ملف PDF")
        }
    }

    fun exportCsv(uri: Uri, type: PeriodType, anchor: LocalDate) = perform {
        try {
            val (s, e) = Periods.range(type, anchor, ZoneId.systemDefault())
            val list = filterTransactions(state.value!!.ledger.transactions, TxFilter(fromMillis = s, toMillisExclusive = e))
            if (writeAndVerify(uri, CsvExport.build(list))) Outcome.Ok("تم تصدير ملف CSV بنجاح")
            else Outcome.Fail("فشل تصدير ملف CSV")
        } catch (e: Exception) {
            Outcome.Fail("فشل تصدير ملف CSV")
        }
    }
}
