package com.hesabati.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.hesabati.app.BuildConfig
import com.hesabati.app.domain.FinanceCalculator
import com.hesabati.app.domain.Money
import com.hesabati.app.domain.PeriodType
import com.hesabati.app.domain.Periods
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun MoreTab(vm: MainViewModel, s: AppState, nav: NavHostController) {
    var sub by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = sub) {
            Tab(selected = sub == 0, onClick = { sub = 0 }, text = { Text("التقارير", fontSize = 16.sp) })
            Tab(selected = sub == 1, onClick = { sub = 1 }, text = { Text("الإعدادات", fontSize = 16.sp) })
        }
        if (sub == 0) ReportsPane(vm, s) else SettingsPane(vm, s, nav) { sub = 0 }
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = GreenColor, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun ReportsPane(vm: MainViewModel, s: AppState) {
    val zone = ZoneId.systemDefault()
    var type by rememberSaveable { mutableStateOf(PeriodType.MONTH) }
    var anchorDay by rememberSaveable { mutableLongStateOf(LocalDate.now(zone).toEpochDay()) }
    val anchor = LocalDate.ofEpochDay(anchorDay)
    val busy by vm.busy.collectAsState()
    val report = remember(s.ledger, type, anchorDay) {
        Periods.range(type, anchor, zone).let { (a, b) -> FinanceCalculator.report(s.ledger, a, b) }
    }
    val periodLabel = Periods.label(type, anchor)
    val stamp = "${type.name.lowercase()}-${periodLabel.replace('/', '-').replace(' ', '-')}"

    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) vm.exportPdf(uri, type, anchor)
    }
    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) vm.exportCsv(uri, type, anchor)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PeriodType.values().forEach { t ->
                FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t.label) }, modifier = Modifier.weight(1f))
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { anchorDay = Periods.shift(type, anchor, -1).toEpochDay() }) { Text("السابق") }
            Text(periodLabel, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            OutlinedButton(onClick = { anchorDay = Periods.shift(type, anchor, 1).toEpochDay() }) { Text("التالي") }
        }
        TextButton(onClick = { anchorDay = LocalDate.now(zone).toEpochDay() }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("العودة إلى اليوم")
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                SectionHeader("ملخص الفترة")
                InfoRow("الرصيد في بداية الفترة", Money.format(report.openingCash), moneyColor(report.openingCash))
                InfoRow("إجمالي الواردات العادية", Money.format(report.income))
                InfoRow("إجمالي المصروفات العادية", Money.format(report.expense))
                InfoRow("صافي الحركة العادية", Money.format(report.netOrdinary), moneyColor(report.netOrdinary), true)
                InfoRow("صافي الأثر النقدي للديون", Money.format(report.netDebtCash), moneyColor(report.netDebtCash), true)
                InfoRow("الرصيد النقدي في نهاية الفترة", Money.format(report.closingCash), moneyColor(report.closingCash), true)
                SectionHeader("حركات الديون خلال الفترة")
                InfoRow("أموال أقرضتها", Money.format(report.lent))
                InfoRow("أموال استردتها", Money.format(report.collected))
                InfoRow("أموال اقترضتها", Money.format(report.borrowed))
                InfoRow("أموال سددتها", Money.format(report.repaid))
                SectionHeader("الديون في نهاية الفترة")
                InfoRow("المستحقة لك", Money.format(report.owedToMeAtEnd))
                InfoRow("المستحقة عليك", Money.format(report.owedByMeAtEnd))
                SectionHeader("الواردات حسب التصنيف")
                if (report.incomeByCategory.isEmpty()) Text("لا توجد واردات", color = MutedColor)
                report.incomeByCategory.forEach { InfoRow(it.first, Money.format(it.second)) }
                SectionHeader("المصروفات حسب التصنيف")
                if (report.expenseByCategory.isEmpty()) Text("لا توجد مصروفات", color = MutedColor)
                report.expenseByCategory.forEach { InfoRow(it.first, Money.format(it.second)) }
            }
        }
        BigButton("تصدير PDF", { pdfLauncher.launch("hesabati-report-$stamp.pdf") }, enabled = !busy)
        SoftButton("تصدير CSV (الواردات والمصروفات العادية)", { csvLauncher.launch("hesabati-transactions-$stamp.csv") }, enabled = !busy)
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun SettingsPane(vm: MainViewModel, s: AppState, nav: NavHostController, goToReports: () -> Unit) {
    val busy by vm.busy.collectAsState()
    val pending by vm.pendingRestore.collectAsState()
    var editOpening by remember { mutableStateOf(false) }
    var deleteAll by remember { mutableStateOf(false) }

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.createBackup(uri)
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.prepareRestore(uri)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoRow("الرصيد الافتتاحي", Money.format(s.ledger.openingBalance), bold = true)
                SoftButton("تعديل الرصيد الافتتاحي", { editOpening = true })
            }
        }
        SoftButton("إدارة التصنيفات", { nav.navigate("categories") })
        SoftButton("تصدير التقارير", goToReports)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("النسخ الاحتياطي", fontWeight = FontWeight.Bold)
                Text("ملف النسخة الاحتياطية غير مشفر، احفظه في مكان آمن.", fontSize = 13.sp, color = MutedColor)
                BigButton("إنشاء نسخة احتياطية", { backupLauncher.launch("hesabati-backup.json") }, enabled = !busy)
                SoftButton("استعادة نسخة احتياطية", { restoreLauncher.launch(arrayOf("*/*")) }, enabled = !busy)
            }
        }
        SoftButton("حذف جميع البيانات", { deleteAll = true }, danger = true)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("حساباتي", fontWeight = FontWeight.Bold)
                Text("الإصدار ${BuildConfig.VERSION_NAME}", fontSize = 13.sp, color = MutedColor)
                Text("البيانات محفوظة على هذا الهاتف فقط، ولا يستخدم التطبيق الإنترنت.", fontSize = 13.sp, color = MutedColor)
            }
        }
    }

    if (editOpening) {
        var text by remember { mutableStateOf(s.ledger.openingBalance.toString()) }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { editOpening = false },
            title = { Text("تعديل الرصيد الافتتاحي") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("تنبيه: تعديل الرصيد الافتتاحي سيؤثر في الرصيد الحالي وصافي الوضع المالي والتقارير.", color = RedColor, fontSize = 14.sp)
                    AmountField(text, { text = it; err = null }, "الرصيد الافتتاحي (د.ع)", error = err)
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    when (val r = Money.parse(text, allowZero = true)) {
                        is Money.ParseResult.Error -> err = r.message
                        is Money.ParseResult.Ok -> vm.perform(onFail = { err = it }, onSuccess = { editOpening = false }) {
                            vm.repo.setOpeningBalance(r.value)
                        }
                    }
                }) { Text("حفظ التعديل", fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { editOpening = false }) { Text("إلغاء") } }
        )
    }

    pending?.let { d ->
        ConfirmDialog(
            "استعادة نسخة احتياطية",
            "الملف سليم ويحتوي على ${d.transactions.size} عملية و${d.debts.size} دين و${d.payments.size} دفعة و${d.categories.size} تصنيف.\n\n" +
                "تحذير: الاستعادة ستستبدل جميع بياناتك الحالية بمحتوى هذا الملف ولن تُدمج معها. " +
                "سيُنشئ التطبيق نسخة أمان تلقائية من بياناتك الحالية قبل الاستبدال.",
            "استبدال البيانات", { vm.confirmRestore() }, { vm.cancelRestore() }, danger = true
        )
    }

    if (deleteAll) {
        var word by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { deleteAll = false },
            title = { Text("حذف جميع البيانات", color = RedColor, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("سيتم حذف جميع العمليات والديون والدفعات والتصنيفات والرصيد الافتتاحي من التطبيق حذفاً نهائياً. ملفات النسخ الاحتياطية الخارجية لن تُحذف.", fontSize = 14.sp)
                    Text("للتأكيد اكتب كلمة: حذف", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    TextInput(word, { word = it }, "اكتب الكلمة هنا")
                }
            },
            confirmButton = {
                TextButton(enabled = word == "حذف" && !busy, onClick = {
                    vm.perform(onSuccess = { deleteAll = false; vm.selectedTab.value = 0 }) { vm.repo.deleteAll() }
                }) { Text("حذف نهائي", color = if (word == "حذف") RedColor else MutedColor, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { deleteAll = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun CategoriesScreen(vm: MainViewModel, s: AppState, nav: NavHostController) {
    val busy by vm.busy.collectAsState()
    var newName by remember { mutableStateOf("") }
    var newErr by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<com.hesabati.app.data.CategoryEntity?>(null) }
    var deleting by remember { mutableStateOf<com.hesabati.app.data.CategoryEntity?>(null) }

    SubScreen("إدارة التصنيفات", { nav.popBackStack() }) {
        TextInput(newName, { newName = it; newErr = null }, "اسم تصنيف جديد", error = newErr)
        BigButton("إضافة التصنيف", {
            vm.perform(onFail = { newErr = it }, onSuccess = { newName = "" }) { vm.repo.addCategory(newName) }
        }, enabled = !busy)
        if (s.categories.isEmpty()) Text("لا توجد تصنيفات", color = MutedColor)
        s.categories.forEach { c ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(start = 14.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(c.name, Modifier.weight(1f), fontSize = 16.sp)
                    TextButton(onClick = { renaming = c }) { Text("تعديل") }
                    TextButton(onClick = { deleting = c }) { Text("حذف", color = RedColor) }
                }
            }
        }
    }

    renaming?.let { c ->
        var text by remember(c.id) { mutableStateOf(c.name) }
        var err by remember(c.id) { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("تعديل التصنيف") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("العمليات القديمة تحتفظ باسم التصنيف الذي سُجلت به.", fontSize = 13.sp, color = MutedColor)
                    TextInput(text, { text = it; err = null }, "اسم التصنيف", error = err)
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    vm.perform(onFail = { err = it }, onSuccess = { renaming = null }) { vm.repo.renameCategory(c.id, text) }
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("إلغاء") } }
        )
    }
    deleting?.let { c ->
        ConfirmDialog(
            "حذف التصنيف",
            "سيُحذف التصنيف «${c.name}» من قائمة الاختيار، وتبقى العمليات القديمة والتقارير محتفظة باسمه.",
            "حذف", {
                deleting = null
                vm.perform { vm.repo.deleteCategory(c.id) }
            }, { deleting = null }, danger = true
        )
    }
}
