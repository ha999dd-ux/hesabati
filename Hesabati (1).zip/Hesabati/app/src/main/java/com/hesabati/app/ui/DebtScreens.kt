package com.hesabati.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.hesabati.app.data.DebtPaymentEntity
import com.hesabati.app.data.Kind
import com.hesabati.app.domain.FinanceCalculator
import com.hesabati.app.domain.DebtView
import com.hesabati.app.domain.Fmt
import com.hesabati.app.domain.Money

@Composable
fun DebtsTab(s: AppState, nav: NavHostController) {
    var dir by rememberSaveable { mutableStateOf(Kind.LENT) }
    var showPaid by rememberSaveable { mutableStateOf(false) }
    val views = remember(s.ledger) { FinanceCalculator.debtViews(s.ledger) }
    val inDir = views.filter { it.debt.direction == dir }
    val active = inDir.filter { !it.isPaid }.sortedByDescending { it.debt.createdAt }
    val paid = inDir.filter { it.isPaid }.sortedByDescending { it.debt.createdAt }
    val total = active.fold(0L) { a, v -> a + v.remaining }

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = if (dir == Kind.LENT) 0 else 1) {
            Tab(selected = dir == Kind.LENT, onClick = { dir = Kind.LENT }, text = { Text("ديون لك", fontSize = 16.sp) })
            Tab(selected = dir == Kind.BORROWED, onClick = { dir = Kind.BORROWED }, text = { Text("ديون عليك", fontSize = 16.sp) })
        }
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
        ) {
            item {
                StatCard(
                    if (dir == Kind.LENT) "إجمالي الديون النشطة لك" else "إجمالي الديون النشطة عليك",
                    total, Modifier.fillMaxWidth()
                )
            }
            item { BigButton("+ إضافة دين", { nav.navigate("debt_add/$dir") }) }
            if (active.isEmpty()) item { Text("لا توجد ديون نشطة", color = MutedColor) }
            items(active, key = { it.debt.id }) { v -> DebtCard(v) { nav.navigate("debt/${v.debt.id}") } }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("عرض الديون المسددة", Modifier.weight(1f))
                    Switch(checked = showPaid, onCheckedChange = { showPaid = it })
                }
            }
            if (showPaid) {
                if (paid.isEmpty()) item { Text("لا توجد ديون مسددة", color = MutedColor) }
                items(paid, key = { it.debt.id }) { v -> DebtCard(v) { nav.navigate("debt/${v.debt.id}") } }
            }
        }
    }
}

@Composable
fun DebtCard(v: DebtView, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(v.debt.personName, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    if (v.isPaid) "مسدد" else "نشط",
                    color = if (v.isPaid) MutedColor else GreenColor, fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(6.dp))
            InfoRow("المبلغ الأصلي", Money.format(v.debt.originalAmount))
            InfoRow(if (v.debt.direction == Kind.LENT) "المسترد" else "المسدد", Money.format(v.paid))
            InfoRow("المتبقي", Money.format(v.remaining), bold = true)
            if (v.debt.note.isNotBlank()) Text(v.debt.note, fontSize = 13.sp, color = MutedColor)
        }
    }
}

@Composable
fun DebtFormScreen(vm: MainViewModel, initialDir: String, nav: NavHostController) {
    val busy by vm.busy.collectAsState()
    var dir by remember { mutableStateOf(if (initialDir == Kind.BORROWED) Kind.BORROWED else Kind.LENT) }
    var person by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var time by remember { mutableStateOf(System.currentTimeMillis()) }
    var personError by remember { mutableStateOf<String?>(null) }
    var amountError by remember { mutableStateOf<String?>(null) }

    SubScreen("إضافة دين", { nav.popBackStack() }) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(selected = dir == Kind.LENT, onClick = { dir = Kind.LENT }, label = { Text("دين لك", fontSize = 16.sp) }, modifier = Modifier.weight(1f))
            FilterChip(selected = dir == Kind.BORROWED, onClick = { dir = Kind.BORROWED }, label = { Text("دين عليك", fontSize = 16.sp) }, modifier = Modifier.weight(1f))
        }
        Text(
            if (dir == Kind.LENT) "أقرضتَ هذا المبلغ لشخص: سينقص النقد ويزيد الدين المستحق لك"
            else "اقترضتَ هذا المبلغ من شخص: سيزيد النقد ويزيد الدين المستحق عليك",
            fontSize = 13.sp, color = MutedColor
        )
        TextInput(person, { person = it; personError = null }, "اسم الشخص", error = personError)
        AmountField(amountText, { amountText = it; amountError = null }, "المبلغ الأصلي (د.ع)", error = amountError)
        TextInput(note, { note = it }, "ملاحظات (اختياري)", singleLine = false)
        DateTimeField(time, { time = it }, "التاريخ والوقت")
        BigButton("حفظ الدين", {
            if (busy) return@BigButton
            personError = if (person.isBlank()) "اكتب اسم الشخص" else null
            val parsed = Money.parse(amountText)
            amountError = (parsed as? Money.ParseResult.Error)?.message
            if (personError == null && parsed is Money.ParseResult.Ok) {
                vm.perform(onSuccess = {
                    vm.selectedTab.value = 2
                    nav.popBackStack("main", false)
                }) { vm.repo.addDebt(dir, person, parsed.value, note, time) }
            }
        }, enabled = !busy)
    }
}

@Composable
fun DebtDetailScreen(vm: MainViewModel, s: AppState, id: Long, nav: NavHostController) {
    val view = FinanceCalculator.debtViews(s.ledger).find { it.debt.id == id }
    if (view == null) {
        SubScreen("الدين", { nav.popBackStack() }) { Text("لم يعد هذا الدين موجوداً") }
        return
    }
    val d = view.debt
    val lent = d.direction == Kind.LENT
    val pays = s.ledger.payments.filter { it.debtId == id }.sortedByDescending { it.dateTime }
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<DebtPaymentEntity?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    SubScreen(d.personName, { nav.popBackStack() }) {
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                InfoRow("النوع", if (lent) "دين لك" else "دين عليك")
                InfoRow("المبلغ الأصلي", Money.format(d.originalAmount))
                InfoRow(if (lent) "المبلغ المسترد" else "المبلغ المسدد", Money.format(view.paid))
                InfoRow("المتبقي", Money.format(view.remaining), bold = true)
                InfoRow("الحالة", if (view.isPaid) "مسدد" else "نشط", if (view.isPaid) MutedColor else GreenColor, true)
                InfoRow("تاريخ الدين", Fmt.dateTime(d.createdAt))
                if (d.note.isNotBlank()) Text("ملاحظات: " + d.note, fontSize = 14.sp, color = MutedColor)
            }
        }
        BigButton(if (lent) "تسجيل استرداد" else "تسجيل سداد", { adding = true }, enabled = !view.isPaid)
        Text("الدفعات", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        if (pays.isEmpty()) Text("لا توجد دفعات بعد", color = MutedColor)
        pays.forEach { p ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { editing = p },
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(Fmt.dateTime(p.dateTime), Modifier.weight(1f), fontSize = 14.sp)
                    Text(Money.format(p.amount), fontWeight = FontWeight.Bold)
                }
            }
        }
        if (pays.isNotEmpty()) Text("لا يمكن حذف دين له دفعات. يمكنك تعديل الدفعات أو إلغاؤها من القائمة أعلاه", fontSize = 13.sp, color = MutedColor)
        else SoftButton("حذف الدين", { confirmDelete = true }, danger = true)
    }

    if (adding) {
        PaymentDialog(vm, if (lent) "تسجيل استرداد" else "تسجيل سداد", null, id, view.remaining) { adding = false }
    }
    editing?.let { p ->
        PaymentDialog(vm, "تعديل الدفعة", p, id, view.remaining + p.amount) { editing = null }
    }
    if (confirmDelete) {
        ConfirmDialog("حذف الدين", "هل أنت متأكد من حذف هذا الدين؟", "حذف", {
            confirmDelete = false
            vm.perform(onSuccess = { nav.popBackStack() }) { vm.repo.deleteDebt(id) }
        }, { confirmDelete = false }, danger = true)
    }
}

@Composable
fun PaymentDialog(
    vm: MainViewModel,
    title: String,
    existing: DebtPaymentEntity?,
    debtId: Long,
    limit: Long,
    onClose: () -> Unit
) {
    val busy by vm.busy.collectAsState()
    var amountText by remember { mutableStateOf(existing?.amount?.toString() ?: "") }
    var time by remember { mutableStateOf(existing?.dateTime ?: System.currentTimeMillis()) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmCancel by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("المتبقي الذي يمكن تسجيله: " + Money.format(limit), fontSize = 13.sp, color = MutedColor)
                AmountField(amountText, { amountText = it; error = null }, "المبلغ (د.ع)", error = error)
                DateTimeField(time, { time = it }, "التاريخ والوقت")
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                when (val r = Money.parse(amountText)) {
                    is Money.ParseResult.Error -> error = r.message
                    is Money.ParseResult.Ok -> {
                        if (r.value > limit) {
                            error = "المبلغ أكبر من المتبقي. المتبقي الصحيح هو ${Money.format(limit)}"
                        } else {
                            vm.perform(onFail = { error = it }, onSuccess = onClose) {
                                if (existing == null) vm.repo.addPayment(debtId, r.value, time)
                                else vm.repo.updatePayment(existing.id, r.value, time)
                            }
                        }
                    }
                }
            }) { Text("حفظ", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            Row {
                if (existing != null) TextButton(onClick = { confirmCancel = true }) { Text("إلغاء الدفعة", color = RedColor) }
                TextButton(onClick = onClose) { Text("رجوع") }
            }
        }
    )
    if (confirmCancel && existing != null) {
        ConfirmDialog("إلغاء الدفعة", "سيتم حذف هذه الدفعة وإعادة حساب المتبقي والنقد. هل تريد المتابعة؟", "إلغاء الدفعة", {
            confirmCancel = false
            vm.perform(onSuccess = onClose) { vm.repo.deletePayment(existing.id) }
        }, { confirmCancel = false }, danger = true)
    }
}
