package com.hesabati.app.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

object Fmt {
    private val dateF = DateTimeFormatter.ofPattern("yyyy/MM/dd", Locale.US)
    private val timeF = DateTimeFormatter.ofPattern("HH:mm", Locale.US)

    fun date(ms: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        dateF.format(Instant.ofEpochMilli(ms).atZone(zone))

    fun time(ms: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        timeF.format(Instant.ofEpochMilli(ms).atZone(zone))

    fun dateTime(ms: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        date(ms, zone) + " " + time(ms, zone)

    fun startOfDay(date: LocalDate, zone: ZoneId = ZoneId.systemDefault()): Long =
        date.atStartOfDay(zone).toInstant().toEpochMilli()
}

enum class PeriodType(val label: String) {
    DAY("يومي"), MONTH("شهري"), YEAR("سنوي")
}

object Periods {
    private val monthNames = listOf(
        "كانون الثاني", "شباط", "آذار", "نيسان", "أيار", "حزيران",
        "تموز", "آب", "أيلول", "تشرين الأول", "تشرين الثاني", "كانون الأول"
    )

    /** يعيد (بداية الفترة شاملة، نهاية الفترة غير شاملة) بالمللي ثانية. */
    fun range(type: PeriodType, anchor: LocalDate, zone: ZoneId): Pair<Long, Long> {
        val start: LocalDate
        val end: LocalDate
        when (type) {
            PeriodType.DAY -> { start = anchor; end = anchor.plusDays(1) }
            PeriodType.MONTH -> { start = anchor.withDayOfMonth(1); end = start.plusMonths(1) }
            PeriodType.YEAR -> { start = anchor.withDayOfYear(1); end = start.plusYears(1) }
        }
        return Fmt.startOfDay(start, zone) to Fmt.startOfDay(end, zone)
    }

    fun shift(type: PeriodType, anchor: LocalDate, delta: Long): LocalDate = when (type) {
        PeriodType.DAY -> anchor.plusDays(delta)
        PeriodType.MONTH -> anchor.plusMonths(delta)
        PeriodType.YEAR -> anchor.plusYears(delta)
    }

    fun label(type: PeriodType, anchor: LocalDate): String = when (type) {
        PeriodType.DAY -> String.format(Locale.US, "%04d/%02d/%02d", anchor.year, anchor.monthValue, anchor.dayOfMonth)
        PeriodType.MONTH -> monthNames[anchor.monthValue - 1] + " " + anchor.year
        PeriodType.YEAR -> anchor.year.toString()
    }
}
